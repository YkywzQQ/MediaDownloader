[app]
version=2.5.4
file=https://google.com

[core]
version=2.5.6
file=https://raw.githubusercontent.com/YkywzQQ/MediaDownloader/refs/heads/main/updater/core.zip